package com.example.projecteuf1;

public class RecyclerBusquedaFragment {
}
