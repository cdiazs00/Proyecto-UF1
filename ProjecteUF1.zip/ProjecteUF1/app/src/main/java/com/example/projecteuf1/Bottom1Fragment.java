package com.example.projecteuf1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.projecteuf1.databinding.FragmentBottom1Binding;

public class Bottom1Fragment extends Fragment {
    private FragmentBottom1Binding binding;
    private MiHipotecaViewModel miHipotecaViewModel;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    public Bottom1Fragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        miHipotecaViewModel = new ViewModelProvider(this).get(MiHipotecaViewModel.class);
    }

    public static Bottom1Fragment newInstance(String param1, String param2) {
        Bottom1Fragment fragment = new Bottom1Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return (binding = FragmentBottom1Binding.inflate(inflater, container, false)).getRoot();
    }

    @SuppressLint("DefaultLocale")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.calcular.setOnClickListener(view1 -> {
            double capital = Double.parseDouble(binding.capital.getText().toString());
            int plazo = Integer.parseInt(binding.plazo.getText().toString());
            miHipotecaViewModel.calcular(capital, plazo);
        });

        miHipotecaViewModel.cuota.observe(getViewLifecycleOwner(), cuota -> binding.cuota.setText(String.format("%.2f", cuota)));

        miHipotecaViewModel.errorCapital.observe(getViewLifecycleOwner(), capitalMinimo -> {
            if (capitalMinimo != null) {
                binding.capital.setError("El capital no puede ser inferior a " + capitalMinimo + " euros");
            } else {
                binding.capital.setError(null);
            }
        });

        miHipotecaViewModel.errorPlazos.observe(getViewLifecycleOwner(), plazoMinimo -> {
            if (plazoMinimo != null) {
                binding.plazo.setError("El plazo no puede ser inferior a " + plazoMinimo + " años");
            } else {
                binding.plazo.setError(null);
            }
        });

        miHipotecaViewModel.calculando.observe(getViewLifecycleOwner(), calculando -> {
            if (calculando) {
                binding.calcular.setVisibility(View.VISIBLE);
                binding.cuota.setVisibility(View.GONE);
            } else {
                binding.calcular.setVisibility(View.VISIBLE);
                binding.cuota.setVisibility(View.VISIBLE);
            }
        });
    }
}