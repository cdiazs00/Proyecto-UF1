package com.example.projecteuf1;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ElementosRepositorio {

    private final Executor executor = Executors.newSingleThreadExecutor();
    private final ElementosBaseDeDatos.ElementosDao elementosDao;

    public ElementosRepositorio(Application application) {
        elementosDao = ElementosBaseDeDatos.obtenerInstancia(application).obtenerElementosDao();
    }

    LiveData<List<Elemento>> obtener() {
        return elementosDao.obtener();
    }

    void insertar(Elemento elemento) {
        executor.execute(() -> elementosDao.insertar(elemento));
    }

    void eliminar(Elemento elemento) {
        executor.execute(() -> elementosDao.eliminar(elemento));
    }
}